<?php get_header(); ?>
	<div id="loadintothis">
		<?php get_template_part( 'single', 'works-content' ); ?>
	</div>
<?php get_footer(); ?>
