<?php
/*
Template Name: Custom Post Type
*/
?>
<?php get_header(); ?>
	
	<div id="loadintothis">
		<?php get_template_part( 'template', 'works-content' ); ?>
	</div>
      
<?php get_footer(); ?>